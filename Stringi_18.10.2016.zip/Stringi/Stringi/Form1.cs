﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stringi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label1.Text = "Dlugosc tekstu:" +
                textBox1.Text.Length;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Length < 1)
            {
                return;
            }
            if (textBox1.Text.Length < 1)
            {
                return;
            }




            int nrZnaku = 0;

            nrZnaku = Int32.Parse(textBox2.Text);
            if (nrZnaku < textBox1.Text.Length)
            {
                label3.Text = "Znak na miejscu "        
                    + nrZnaku + " to: '" + textBox1.Text[nrZnaku - 1] + "'";
            }
            else
            {
                MessageBox.Show("Nie ma aż tyle znaków!!!");
            }
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if(textBox1.Text.Contains(textBox3.Text))
            {
                label4.Text = "TAK!";
            }else
            {
                label4.Text = "Nie :(";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label5.Text = "";

            //char obecnyZnak = ' ';
            //obecnyZnak = textBox1.Text[0];
            int nrZnaku = 0;
            while (!(textBox1.Text[nrZnaku] == ' '))
            {
                label5.Text 
                    = label5.Text + textBox1.Text[nrZnaku];


                nrZnaku = nrZnaku + 1;
            }
        }

        //Wykonuje się podczas zmiany wartości a
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            policzTrygonometrie();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            policzTrygonometrie();
        }

    
        public void policzTrygonometrie()
        {
            //Tworzenie zmiennych
            double a, b, c;
            //Pobieranie a i b

            if (textBox4.Text.Length > 0)
            {
                a = Double.Parse(textBox4.Text);
            }
            else
            {
                a = 0;
            }

            if (textBox5.Text.Length > 0)
            {
                b = Double.Parse(textBox5.Text);
            }
            else
            {
                b = 0;
            }
    //obliczanie c (z tw. Pitagorasa)
    c = Math.Sqrt(a * a + b * b);

            //Wartość c
            textBox6.Text = c + "";
            //Sinus Alpha
            textBox7.Text = a / c + "";
            //Cosinus Alpha
            textBox8.Text = b / c + "";
            //Tangens Alpha
            textBox9.Text = a / b + "";
            //Cotangens Alpha
            textBox10.Text = b / a + "";
        }

    }
}
